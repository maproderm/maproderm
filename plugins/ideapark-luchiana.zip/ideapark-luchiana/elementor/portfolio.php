<?php

use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Ideapark_Elementor_Portfolio extends Widget_Base {
	/**
	 * Retrieve the widget name.
	 */
	public function get_name() {
		return 'ideapark-portfolio';
	}

	/**
	 * Retrieve the widget title.
	 */
	public function get_title() {
		return esc_html__( 'Portfolio', 'ideapark-luchiana' );
	}

	/**
	 * Retrieve the widget icon.
	 */
	public function get_icon() {
		return 'eicon-gallery-group';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 */
	public function get_categories() {
		return [ 'ideapark-elements' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'section_category',
			[
				'label' => __( 'Portfolio', 'ideapark-luchiana' ),
			]
		);

		$options = [
			''          => __( 'All', 'ideapark-luchiana' ),
			'-current-' => __( 'Current category', 'ideapark-luchiana' )
		];
		if ( $categories = get_terms( [
			'taxonomy'   => 'catalog_type',
			'hide_empty' => false,
		] ) ) {
			foreach ( $categories AS $category ) {
				$options[ $category->slug ] = $category->name;
			}
		}
		$this->add_control(
			'category',
			[
				'label'   => __( 'Category', 'ideapark-luchiana' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 0,
				'options' => $options
			]
		);

		$this->add_control(
			'layout',
			[
				'label'   => __( 'Grid layout', 'ideapark-luchiana' ),
				'type'    => Controls_Manager::SELECT,
				'default' => ideapark_mod( 'catalog_grid_layout' ),
				'options' => [
					'3' => __( '3 items per row', 'ideapark-luchiana' ),
					'4' => __( '4 items per row', 'ideapark-luchiana' ),
				]
			]
		);

		$this->add_control(
			'sort',
			[
				'label'   => __( 'Sort', 'ideapark-luchiana' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'menu_order',
				'options' => [
					'menu_order' => __( 'Default sorting', 'ideapark-luchiana' ),
					'rand'       => __( 'Sort by rand', 'ideapark-luchiana' ),
					'date'       => __( 'Sort by latest', 'ideapark-luchiana' ),
				]
			]
		);

		$this->add_control(
			'button',
			[
				'label'   => __( 'Button', 'ideapark-luchiana' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''          => __( 'Hide', 'ideapark-luchiana' ),
					'load_more' => __( 'Load more (ajax-loading)', 'ideapark-luchiana' ),
					'view_all'  => __( 'View all (link to catalog)', 'ideapark-luchiana' ),
				]
			]
		);

		$this->add_control(
			'limit',
			[
				'label'   => __( 'Products count', 'ideapark-luchiana' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
				'default' => 6,
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		global $post;
		$settings = $this->get_settings();
		$args     = [
			'post_type'      => 'catalog',
			'posts_per_page' => $settings['limit'],
			'paged'          => 1,
		];

		switch ( $settings['sort'] ) {
			case 'menu_order':
				$args['orderby'] = 'menu_order';
				$args['order']   = 'ASC';
				break;
			case 'rand':
				$args['orderby'] = 'rand';
				break;
			case 'date':
				$args['orderby']          = 'date';
				$args['order']            = 'DESC';
				$args['suppress_filters'] = true;
				break;
		}

		if ( $settings['category'] == '-current-' ) {
			$settings['category'] = '';
			if ( is_singular( [ 'catalog' ] ) ) {
				$item_terms = wp_get_post_terms( $post->ID, 'catalog_type' );
				if ( $item_terms ) {
					$settings['category'] = $item_terms[0]->slug;
					$args['post__not_in'] = [ $post->ID ];
				}
			}
		}

		if ( $settings['category'] ) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'catalog_type',
					'field'    => 'slug',
					'terms'    => $settings['category'],
				],
			];
		}

		$query = new WP_Query( $args );
		?>
		<div class="c-catalog c-ip-portfolio l-section js-catalog"
			 data-limit="<?php echo esc_attr( $settings['limit'] ); ?>"
			 data-sort="<?php echo esc_attr( $settings['sort'] ); ?>"
			 data-button="<?php echo esc_attr( $settings['button'] ); ?>">
			<div class="l-section__content">
				<?php if ( ! $settings['category'] ) { ?>
					<?php ideapark_get_template_part( 'templates/filter', [ 'is_archive' => false ] ); ?>
				<?php } ?>
				<?php if ( $query->have_posts() ) { ?>
					<div
						class="c-catalog__grid c-catalog__grid--<?php echo $settings['layout']; ?> js-grid">
						<?php while ( $query->have_posts() ) {
							$query->the_post(); ?>
							<?php get_template_part( 'templates/item' ); ?>
						<?php } ?>
					</div>
					<?php if ( $settings['button'] == 'load_more' ) { ?>
						<div class="c-catalog__load-more">
							<?php ideapark_load_more_button( $query, 'catalog', $settings['limit'], $settings['category'], $settings['sort'] ); ?>
						</div>
					<?php } elseif ( $settings['button'] == 'view_all' ) { ?>
						<div class="c-catalog__load-more">
							<?php ideapark_view_all_button( $settings['category'] ) ?>
						</div>
					<?php }
				} ?>
			</div>
		</div>
		<?php
		wp_reset_postdata();
	}

	/**
	 * Render the widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 */
	protected function _content_template() {

	}
}
