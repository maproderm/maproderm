(function ($, root, undefined) {
	"use strict";
	
	$('.ideapark-fonts__item-view').click(function () {
		var $this = $(this);
		var $wrap = $this.closest('.ideapark-fonts__item').find('.ideapark-fonts__wrap');
		$wrap.slideToggle(500, function () {
			$this.toggleClass('dashicons-arrow-down-alt2').toggleClass('dashicons-arrow-up-alt2');
		});
	});
	
	$('.js-ideapark-fonts-font').click(function (e) {
		e.stopPropagation();
		e.preventDefault();
		$(this).closest('.ideapark-fonts__item').find('.ideapark-fonts__item-view').trigger('click');
	});
	
	$('.ideapark-fonts__expand-all').click(function () {
		$('.ideapark-fonts__item-view.dashicons-arrow-down-alt2').trigger('click');
	});
	
	$('.ideapark-fonts__collapse-all').click(function () {
		$('.ideapark-fonts__item-view.dashicons-arrow-up-alt2').trigger('click');
	});
	
	$('.js-ideapark-fonts-icon').click(function (e) {
		var $this = $(this);
		e.stopPropagation();
		e.preventDefault();
		$('.ideapark-fonts__code').html($this.data('class'));
		$('.ideapark-fonts__popup-img').attr('class', 'ideapark-fonts__popup-img').addClass($this.data('class'));
		$('.ideapark-fonts__popup').addClass('ideapark-fonts__popup--active');
	});
	
	$('.ideapark-fonts__popup-close').click(function () {
		$('.ideapark-fonts__popup--active').removeClass('ideapark-fonts__popup--active');
	});
	
})(jQuery, this);
